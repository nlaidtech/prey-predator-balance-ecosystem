"""Test suite package initialization."""
